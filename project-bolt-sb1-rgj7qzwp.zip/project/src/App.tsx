import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, AlertTriangle } from 'lucide-react';

interface Message {
  text: string;
  isUser: boolean;
}

function App() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    // Add initial greeting
    setMessages([
      {
        text: "👋 Hi! I'm CryptoBuddy, your friendly cryptocurrency advisor. How can I help you today?\n\nTry asking me:\n• Which crypto is trending up?\n• What's the most sustainable coin?\n• Which crypto is best for long-term growth?",
        isUser: false,
      },
    ]);
    
    // Focus input on load
    inputRef.current?.focus();
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    // Add user message
    setMessages(prev => [...prev, { text: input, isUser: true }]);

    // Simulate bot response
    setTimeout(() => {
      let response = "I'm still learning about cryptocurrencies. Try asking about trending coins, sustainability, or long-term growth potential!";
      
      const query = input.toLowerCase();
      if (query.includes('trending') || query.includes('going up')) {
        response = "📈 Bitcoin (BTC) and Ethereum (ETH) are currently trending up with strong market performance. Both show rising price trends and high market caps.";
      } else if (query.includes('sustainable') || query.includes('green')) {
        response = "🌱 Algorand (ALGO) and Cardano (ADA) are leading in sustainability. They use proof-of-stake consensus with minimal energy consumption.";
      } else if (query.includes('long-term') || query.includes('growth')) {
        response = "🔮 For long-term growth potential, consider Ethereum (ETH) and Polkadot (DOT). They combine strong market presence with sustainable practices.";
      }

      setMessages(prev => [...prev, { text: response, isUser: false }]);
    }, 1000);

    setInput('');
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center gap-3">
          <Bot className="w-8 h-8 text-blue-600" />
          <h1 className="text-xl font-semibold text-gray-900">CryptoBuddy</h1>
        </div>
      </header>

      {/* Chat Container */}
      <div className="flex-1 max-w-4xl w-full mx-auto p-4 flex flex-col">
        {/* Messages */}
        <div className="flex-1 overflow-y-auto mb-4 space-y-4">
          {messages.map((message, index) => (
            <div
              key={index}
              className={`flex ${message.isUser ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[80%] rounded-lg px-4 py-2 ${
                  message.isUser
                    ? 'bg-blue-600 text-white'
                    : 'bg-white text-gray-900 shadow-sm'
                }`}
              >
                <pre className="whitespace-pre-wrap font-sans">{message.text}</pre>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>

        {/* Disclaimer */}
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 mb-4 flex items-start gap-2">
          <AlertTriangle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
          <p className="text-sm text-yellow-700">
            Cryptocurrency investments involve significant risks. This is educational information only. Always do your own research before investing.
          </p>
        </div>

        {/* Input Form */}
        <form onSubmit={handleSubmit} className="flex gap-2">
          <input
            ref={inputRef}
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask about crypto trends, sustainability, or investment advice..."
            className="flex-1 rounded-lg border border-gray-300 px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          <button
            type="submit"
            className="bg-blue-600 text-white rounded-lg px-4 py-2 flex items-center gap-2 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
          >
            <Send className="w-4 h-4" />
            <span>Send</span>
          </button>
        </form>
      </div>
    </div>
  );
}

export default App;